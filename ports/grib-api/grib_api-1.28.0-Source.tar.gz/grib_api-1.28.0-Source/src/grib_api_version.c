#include "grib_api_internal.h"

const char * grib_get_git_sha1() { return "98591ff4a815d13cba577763a3fcc5b52b53dc64"; }
